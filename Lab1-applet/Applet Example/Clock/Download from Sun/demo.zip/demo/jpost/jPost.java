/*
 * (c) 2000 Sun Microsystems, Inc.
 * ALL RIGHTS RESERVED
 * 
 * License Grant-
 * 
 * 
 * Permission to use, copy, modify, and distribute this Software and its 
 * documentation for NON-COMMERCIAL or COMMERCIAL purposes and without fee is 
 * hereby granted.  
 * 
 * This Software is provided "AS IS".  All express warranties, including any 
 * implied warranty of merchantability, satisfactory quality, fitness for a 
 * particular purpose, or non-infringement, are disclaimed, except to the extent  
 * that such disclaimers are held to be legally invalid.
 * 
 * You acknowledge that Software is not designed, licensed or intended for use 
 * in the design, construction, operation or maintenance of any nuclear facility 
 * ("High Risk Activities").  Sun disclaims any express or implied warranty of 
 * fitness for such uses.  
 * 
 * Please refer to the file http://www.sun.com/policies/trademarks/ for further 
 * important trademark information and to 
 * http://java.sun.com/nav/business/index.html for further important licensing 
 * information for the Java Technology.
 */

import java.applet.Applet;
import java.awt.*;
import java.lang.*;
import java.net.*;
import java.io.*;
import java.util.*;

/*
 * jPost implements Runnable in order to animate the arrows
 * and to frequently check the status of the image load when the
 * applet is first starting up
 */
public class jPost extends Applet implements Runnable {
    boolean	runNow, popUpState, goingUp, needToDoInit;
    boolean	isError, loggedIn, doAnimation, handleClick;
    boolean	hasImage, imageClickable, graphicLoaded, debugOn; 
    Color	animationColor[];
    Color 	bgColor = Color.white;	
    Color 	defaultFontColor = Color.black;
    Color	animationLightColor = Color.white;
    Color	animationDarkColor = Color.black;
    Font	defaultFont;
    Graphics	offscreenBufG, imageBufG, animBufG;
    Image	offscreenImage, imageBufGImage, animImage, cartImage;
    int		xInset,	yInset, apWidth, apHeight, imageTop;
    int 	animationWidth, animateColor, animationSteps;
    int		animationVerticalMiddle, animationPause, imageLeft;
    int		numParameterNames, fontSize, imageHeight, imageWidth;
    String	parameterSep, colorSep, formattingSep, fontFace;
    String	transactionUrl, loginUrl, thisUrl, imageClickUrl;
    String	imageVerticalAlign, defaultFontStyle, newlineString;
    String	parameterString, userID, commonString, errorReturnCode;
    String 	transactionParameterNames[], welcomeString, errorString;
    String	defaultFontColorAbbreviation, defaultFontStyleAbbreviation;
    Thread 	animate;
    URL 	updateURL, imageUrl;

    /*
     * Initialize variables, call getParameters(), and draw welcome message
     */
    public void init() {
	int redIncrement, greenIncrement, blueIncrement;
	int currentRed, currentGreen, currentBlue, loop;

	runNow = false;
	goingUp = true;
	debugOn = false;
	isError = false;
	loggedIn = false;
	hasImage = false;
	doAnimation = true;
	handleClick = false;
	needToDoInit = true;
	graphicLoaded = false;

	yInset = 0;
	imageTop = 0;
	imageLeft = 0;
	animateColor = 0;
	animationSteps = 10;
	animationWidth = 20;
	animationPause = 40;
	apWidth = size().width;
	apHeight = size().height;

	bgColor = Color.white;	
	defaultFontColor = Color.black;

	getParameters();
	
	if (hasImage) {
	    cartImage = getImage(imageUrl);
	}

	animationColor = new Color[animationSteps];
	
	redIncrement = (animationLightColor.getRed()-animationDarkColor.getRed())/animationSteps;
	greenIncrement = (animationLightColor.getGreen()-animationDarkColor.getGreen())/animationSteps;
	blueIncrement = (animationLightColor.getBlue()-animationDarkColor.getBlue())/animationSteps;

	currentRed=animationDarkColor.getRed();
	currentGreen=animationDarkColor.getGreen();
	currentBlue=animationDarkColor.getBlue();
	animationColor[0] = animationLightColor;
	for (loop = 1; loop < animationSteps; loop++) {
	    currentRed+=redIncrement;
	    currentGreen+=greenIncrement;
	    currentBlue+=blueIncrement;
	    animationColor[loop] = new Color(currentRed,currentGreen,currentBlue);
	}
	animationVerticalMiddle = imageTop+imageHeight/2;

	offscreenImage=createImage(apWidth,apHeight);
	offscreenBufG=offscreenImage.getGraphics();
	offscreenBufG.setColor(bgColor);
	offscreenBufG.fillRect(0,0,apWidth,apHeight);

	yInset = offscreenBufG.getFontMetrics(defaultFont).getHeight();

	if (hasImage) {
	    imageBufGImage=createImage(imageWidth,apHeight);
	    imageBufG=imageBufGImage.getGraphics();
	    imageBufG.setColor(bgColor);
	    imageBufG.fillRect(0,0,imageWidth,apHeight);
	    xInset += imageWidth;
	}
	if (doAnimation) {
	    xInset += 5+animationWidth;
	    animImage=createImage(animationWidth,apHeight);
	    animBufG=animImage.getGraphics();
	    animBufG.setColor(bgColor);
	    animBufG.fillRect(0,0,animationWidth,apHeight);
	}

	if (isError) {
	    drawMessage(offscreenBufG, errorString);
	} else {
	    drawMessage(offscreenBufG, welcomeString);
	}
	needToDoInit = false;
    }

    /*
     * Set all the variables to the values specified in the <PARAM tags
     */
    public void getParameters() {
	Integer tempInteger;
	int[] 	ints;
	
	try {
	    parameterSep = new String(getParameter("parameterSep"));
	    formattingSep = new String(getParameter("formattingSep"));
	    colorSep = new String(getParameter("colorSep").trim());
	    defaultFontStyleAbbreviation = new String(getParameter("defaultFontStyleAbbreviation").trim());
	    if (getParameter("hasImage").trim().equals("true")) {
		hasImage = true;
	    }
	    if (hasImage) {
		imageUrl = new URL(new String(getParameter("imageUrl").trim()));
		ints = parseInt(getParameter("imageWidthAndHeight"), parameterSep);
		imageWidth = ints[0];
		imageHeight = ints[1];
		imageVerticalAlign = new String(getParameter("imageVerticalAlign").trim());
		if (imageVerticalAlign.equals("middle")) {
		    imageTop = (apHeight - imageHeight)/2;
		} else if (imageVerticalAlign.equals("bottom")) {
		    imageTop = (apHeight - imageHeight);
		} else {
		    imageTop = 0;
		}
 		if (getParameter("imageClickable").trim().equals("true")) {
		    imageClickable = true;
	    	}
		if (imageClickable) {
		    imageClickUrl = new String(getParameter("imageClickUrl").trim());
		}
	    }
	    defaultFontColorAbbreviation = new String(getParameter("defaultFontColorAbbreviation").trim());
	    newlineString = new String(getParameter("newlineString").trim());

	    fontFace = new String(getParameter("fontFace").trim());
	    tempInteger = new Integer(getParameter("fontSize").trim());
	    fontSize = tempInteger.intValue();
	    errorReturnCode = new String(getParameter("errorReturnCode").trim());
	    transactionUrl = new String(getParameter("transactionUrl").trim());
	    userID = new String(getParameter("userID").trim());
	    thisUrl = new String(getParameter("thisUrl").trim());
	    ints = parseInt(getParameter("bgColor"), colorSep);
	    bgColor = new Color(ints[0], ints[1], ints[2]);
	    welcomeString = new String(getParameter("welcomeString"));
	    errorString = new String(getParameter("errorString"));
	    tempInteger = new Integer(getParameter("numberOfParameterNames").trim());
	    numParameterNames = tempInteger.intValue();
	    ints = parseInt(getParameter("defaultFontColor"), colorSep);
	    defaultFontColor = new Color(ints[0], ints[1], ints[2]);
       	    transactionParameterNames = new String[numParameterNames];
	    transactionParameterNames = parse(getParameter("transactionParameterNames"), parameterSep);
	    if (getParameter("loggedIn").trim().equals("true")) {
		loggedIn = true;
	    } else {
		if (getParameter("handleClick").trim().equals("true")) {
		    handleClick = true;
		    loginUrl = new String(getParameter("loginUrl").trim());
		}
	    }
	    if (getParameter("isError").trim().equals("true")) {
		isError = true;
	    }
	    if (getParameter("debugOn").trim().equals("true")) {
		debugOn = true;
	    }
	    if (getParameter("doAnimation").trim().equals("false")) {
		doAnimation = false;
		animationWidth = 0;
	    }
	    if (doAnimation) {
		tempInteger = new Integer(getParameter("animationWidth").trim());
	    	animationWidth = tempInteger.intValue();
		tempInteger = new Integer(getParameter("animationSteps").trim());
	    	animationSteps = tempInteger.intValue();
		ints = parseInt(getParameter("animationLightColor"), colorSep);
	   	animationLightColor = new Color(ints[0], ints[1], ints[2]);
	    	ints = parseInt(getParameter("animationDarkColor"), colorSep);
	   	animationDarkColor = new Color(ints[0], ints[1], ints[2]);
		tempInteger = new Integer(getParameter("animationPause").trim());
	    	animationPause = tempInteger.intValue();
	    }
	    if (getParameter("defaultFontStyle").trim().equals("BOLD")) {
		defaultFont = new Font(fontFace, Font.BOLD, fontSize);
	    } else if (getParameter("defaultFontStyle").trim().equals("ITALIC")) {
	    	defaultFont = new Font(fontFace, Font.ITALIC, fontSize);
	    } else {
	    	defaultFont = new Font(fontFace, Font.PLAIN, fontSize);
	    }
	} catch (Exception e) {
	    e.printStackTrace();
	}
    }

    /*
     * Animate the transaction arrows to the database if
     * animate is true and we are waiting for response from backend
     */
    public void run() {
      while ( Thread.currentThread() == animate) {
        try {
          if (doAnimation && runNow) {
	    if (goingUp) {
		if (animateColor < animationSteps-2)  {
		    animateColor++;
	    	} else {
		    goingUp = false;
		}
	    } else {
		if (animateColor > 1)  {
		    animateColor--;
	    	} else {
		    goingUp = true;
		}
	    }
	    animBufG.setColor(animationColor[animateColor]);
	    animBufG.drawLine(2,animationVerticalMiddle-1,animationWidth-2,animationVerticalMiddle-1);
	    animBufG.drawLine(2,animationVerticalMiddle-1,2+animationWidth/4,animationVerticalMiddle-animationWidth/4);
	    animBufG.setColor(animationColor[animationSteps-animateColor]);
	    animBufG.drawLine(2,animationVerticalMiddle+1,animationWidth-2,animationVerticalMiddle+1);
	    animBufG.drawLine(animationWidth-2,animationVerticalMiddle+1,animationWidth-2-animationWidth/4,animationVerticalMiddle+animationWidth/4);
	    offscreenBufG.drawImage(animImage,imageWidth+2,0,this);
	    repaint();
	    Thread.sleep(animationPause);
	  } else {
	    offscreenBufG.setColor(bgColor);
	    offscreenBufG.fillRect(imageWidth+3,0,animationWidth,apHeight);
	    repaint();
	    Thread.sleep(animationPause);
	  }
	  /* 
	   * Check on progess of loading the graphic,
	   * if not yet loaded get it again and draw it again.
	   */
	  if (hasImage && !graphicLoaded) {
	     graphicLoaded = imageBufG.drawImage(cartImage, imageLeft, imageTop, this);
	     offscreenBufG.drawImage(imageBufGImage,0,0,this);
	     repaint();
	  }
        } catch(InterruptedException e) {
           e.printStackTrace();
        }
      }
    }

    /*
     * If initialization has been done, start the animation thread
     */
    public void start() {
	if (!needToDoInit) {
	    if ( (animate == null) || (!animate.isAlive()) ) {
		animate = new Thread(this);
      	    }
      	    animate.start();
   	}
    }

    /*
     * Stop the animation thread
     */
    public void stop() {
       if ((animate != null) && (animate.isAlive())) {
          animate.stop();
       }
    }

    /*
     * Clean up memory and threads after the applet is no longer needed
     */
    public void destroy() {
	animate = null;
	cartImage.flush();
	animImage.flush();
	if (hasImage) {
	    imageBufGImage.flush();
	    imageBufG.dispose();
	}
    	offscreenImage.flush();
	animBufG.dispose();

	offscreenBufG.dispose();
    }

    /*
     * Whenever paint() is called, copy the offscreen
     * image to the visible graphics context
     */
    public void drawMessage(Graphics g, String transactionFeedback) {
	String[] 	stringsWithFormats, parts; 
	Font		tempFont = defaultFont;
	int[]		ints;
	int 		loop;
	int		xCurrentInset = xInset;
	int		yCurrentInset = yInset;

	g.setColor(bgColor);
	g.fillRect(0,0,apWidth,apHeight);

	if (hasImage) {
	    g.drawImage(imageBufGImage,0,0,this);
	}

	stringsWithFormats = parse(transactionFeedback,parameterSep);

	for (loop = 0; loop < stringsWithFormats.length; loop++) {
	    //Split the formatting data
	    parts = parse(stringsWithFormats[loop],formattingSep);

	    //Determine and set Font Style for this string
	    if (parts[0].equals(defaultFontStyleAbbreviation)) {
		tempFont = defaultFont;
	    } else {
		if (parts[0].equals("BOLD")) {
		    tempFont = new Font(fontFace, Font.BOLD, fontSize);
		} else if (parts[0].equals("ITALIC")) {
		    tempFont = new Font(fontFace, Font.ITALIC, fontSize);
		} else {
		    tempFont = new Font(fontFace, Font.PLAIN, fontSize);
		}
	    }
	    g.setFont(tempFont);

	    //Determine and set the Font Color for this string
	    if (parts[1].equals(defaultFontColorAbbreviation)) {
		g.setColor(Color.black);
	    } else {
		//Parse the custom color data
		ints = parseInt(parts[1], colorSep);
		g.setColor(new Color(ints[0], ints[1], ints[2]));
	    }

	    //Draw the String or increment the y offset in response to a newline
	    if (parts[2].equals(newlineString)) {
		yCurrentInset=yCurrentInset+g.getFontMetrics(defaultFont).getHeight();
		xCurrentInset=xInset;
	    } else {
		g.drawString(parts[2],xCurrentInset,yCurrentInset);
		xCurrentInset+=g.getFontMetrics(tempFont).stringWidth(parts[2]);
	    }
	}
    }

    /*
     * Whenever paint() is called, copy the offscreen
     * image to the visible graphics context
     */
    public void paint(Graphics g) {
	g.drawImage(offscreenImage,0,0,this);
    }

    /* 
     * Whenever update() is called, simply do paint()
     */
    public void update(Graphics g) {
	paint(g);
    }

    /* 
     * Called by JavaScript in HTML page:
     * Construct the URL and send as a GET to the transactionUrl
     * by appending the necessary parameters and their values
     */
    public boolean doPost(String parameterValueString) {
	boolean successfulTransaction = false;
	StringBuffer paramStrBuf = new StringBuffer("userID="+userID+"&");
	StringBuffer response = new StringBuffer();
	String[] parameterValueArray = new String[numParameterNames];
	parameterValueArray = parse(parameterValueString,parameterSep);
	int loop;

	runNow = true;
	try {
	    for (loop=0;  loop<numParameterNames; loop++) {
		paramStrBuf.append(transactionParameterNames[loop]+"="+URLEncoder.encode(parameterValueArray[loop])+"&");
	    }
	    paramStrBuf.append("ts="+String.valueOf((new java.util.Date()).getTime()));
	    updateURL = new URL(transactionUrl+"?"+paramStrBuf.toString());
	} catch (MalformedURLException e) {
	    e.printStackTrace();
	}
	if (debugOn) {	
	    System.out.println("\nSending http GET:\n"+transactionUrl+"?"+paramStrBuf.toString());
	}
	try {
	    URLConnection con = updateURL.openConnection();

            BufferedReader in = new BufferedReader(new InputStreamReader( con.getInputStream() ) );
            String inputLine;
	    if (debugOn) {
	    	System.out.println("Returned the following:");
	    }
            while ( ( inputLine = in.readLine() ) != null ) {
		if (debugOn) {
		    System.out.println(inputLine);
		}
		response.append(inputLine);
            }
            in.close();
	    if (response.toString().indexOf(formattingSep) != -1) {
		successfulTransaction = true;
	    } else {
		successfulTransaction = false;
	    }
	} catch (IOException e) {
	    e.printStackTrace();
	}
	if (successfulTransaction) {
	    drawMessage(offscreenBufG,response.toString());
	    repaint();
	} else {
	    try {
		URL tempURL;
		if (thisUrl.indexOf("isError=true") != -1) {
		    tempURL = new URL(thisUrl); 	
		} else if (thisUrl.indexOf("?") != -1) {
		    tempURL = new URL(thisUrl+"&isError=true");
		} else {
		    tempURL = new URL(thisUrl+"?isError=true");
		}
		stop();
		destroy();
		getAppletContext().showDocument(tempURL);
	    }
	    catch (Exception e) {
		e.printStackTrace();
	    }
	}
	runNow = false;
	return successfulTransaction;
    }

    /* 
     * Send user to login URL if not logged in,or to imageClickUrl if enabled
     */
    public boolean mouseUp(Event evt, int x, int y) {
	if ((!loggedIn) && (!isError) && (handleClick)) {
	    try {
		 URL tempURL = new URL(loginUrl);
		 stop();
		 destroy();
		 getAppletContext().showDocument(tempURL);
	    }
	    catch (Exception e) {
		e.printStackTrace();
	    }
	} else if (imageClickable && x < xInset) {
	    try {
		 URL tempURL;
		 if (imageClickUrl.indexOf("?") != -1) {
			tempURL = new URL(imageClickUrl+"&userID="+userID+"&ts="+String.valueOf((new java.util.Date()).getTime()));
		 } else {
			tempURL = new URL(imageClickUrl+"?userID="+userID+"&ts="+String.valueOf((new java.util.Date()).getTime()));
		 }
		 stop();
		 destroy();
		 getAppletContext().showDocument(tempURL);
	    }
	    catch (Exception e) {
		e.printStackTrace();
	    }
	}
	return(true);
    }

    /* 
     * s is a string containing 'sep' separators.  This method
     * breaks up the string at the separators and returns the resulting
     * strings in an array.  The result may have zero length but is never null.
     */
    String[] parse(String s, String sep)
    {
       StringTokenizer st = new StringTokenizer(s, sep);
       String result[] = new String[st.countTokens()];

       for (int i = 0; i < result.length; i++) {
          result[i] = st.nextToken();
       }
       
       return result;
    }

    /*
     * This method is similar to parse() except that the strings are 
     * assumed to be decimal integers.  This method coverts these integer
     * strings into integers and returns them in an array.
     * The result may have zero length but is never null.
     */
    int[] parseInt(String s, String sep) {
	StringTokenizer st = new StringTokenizer(s, sep);
        int[] result = new int[st.countTokens()];

	for (int i=0; i<result.length; i++) {
            result[i] = Integer.parseInt(st.nextToken());
	}
        return result;
    }
}
