		// Fig. 4.13: AnalysisTest.java
		// Test program for class Analysis.
		
		public class AnalysisTest 
		{
		   public static void main( String args[] ) 
		   {
		      Analysis application = new Analysis(); // create Analysis object
		      application.processExamResults(); // call method to process results
		   } // end main
		
		} // end class AnalysisTest
