public class TriangleApp
{
   public static void main(String[] args)
   {
      Triangle a=new Triangle(3,5,6);
      System.out.println(a.findArea());
      System.out.println(a.findPerimeter());
   }
}

