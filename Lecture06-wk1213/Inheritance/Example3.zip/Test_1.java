public class Test_1 {

	public static void main(String args[]) {
		
		CIT_Student cit = new CIT_Student(1001,"Chan Tai Man");
		//Student s = new Student(1003,"peter");
		
		cit.setCIT_grade(99.9f); // subclass method
		cit.setYear(2); // inherited method
		
		System.out.println("CIT Student info: ");
		System.out.println("id: \t"+ cit.getId());
		System.out.println("name: \t"+ cit.getName());
		System.out.println("year: \t"+ cit.getYear());
		System.out.println("CIT: \t"+ cit.getCIT_grade());
		System.out.println("The sub name is " + cit.getSubjName());
		
		System.out.println();
		Logistics_Student log_s=new Logistics_Student(1000,"Chan Siu Ming");
		//Logistics_Student log_s=new Logistics_Student();
		
		log_s.setLOG_grade(90.9f); // subclass method
		log_s.setYear(1); // inherited method
		
		System.out.println("LOG Student info: ");
		System.out.println("id: \t"+ log_s.getId());
		System.out.println("name: \t"+ log_s.getName());
		System.out.println("year: \t"+ log_s.getYear());
		System.out.println("LOG: \t"+ log_s.getLOG_grade());
		System.out.println("The sub name is " + log_s.getSubjName());
		

	
	
	
	}
}